All the data is from LAcounty: https://data.lacounty.gov/browse

COUNT.CSV is the dataset that states how many number of crimes in every crime category from 2010 to 2014

LA_CRIMES10to14.csv is the dataset before doing feature engineering containing 2010—2014 crimes

LA_CRIMESDATA.csv is the dataset after doing data cleaning, preliminary feature engineering and only contains 2010—2014 crimes in LA.

LA_CRIMESDATA_BACKUP.csv is the dataset after doing the feature engineering(added some features)

test_data.csv is the dataset that I only choose 2 type crimes(13,16)

123.py: to find the correlation between number of trees and test/train_score, output treefile and accuracy_vs_no_of_trees.png

hw2.py: the main python file

Firstly, run 123.py
Then, run hw2.py

